using System;
using System.Windows.Forms;
using EPL_DBMS.DataAccess;

namespace EPL_DBMS.Forms
{
    public partial class PlayerInjuriesForm : Form
    {
        private readonly int? _playerId;

        // Called from Main Menu
        public PlayerInjuriesForm()
        {
            InitializeComponent();
            _playerId = null;
            this.Text = "League Injury Report";
            this.Load += Form_Load;
        }

        // Called from Players Form
        public PlayerInjuriesForm(int playerId, string playerName)
        {
            InitializeComponent();
            _playerId = playerId;
            this.Text = $"{playerName} - Injury History";
            this.Load += Form_Load;
        }

        private void Form_Load(object sender, EventArgs e)
        {
            try
            {
                var dgv = dataGridViewPlayerInjuries;

                // --- PURE ADO.NET ROUTING ---
                if (_playerId.HasValue)
                {
                    // Calls the ADO.NET method with the WHERE clause
                    dgv.DataSource = PlayerInjuryRepository.GetByPlayerId(_playerId.Value);
                    dgv.Columns["PlayerId"].Visible = false;
                }
                else
                {
                    // Calls the ADO.NET method that gets everything
                    dgv.DataSource = PlayerInjuryRepository.GetAllInjuries();
                    dgv.Columns["PlayerId"].HeaderText = "Player ID";
                }

                dgv.Columns["InjuryDate"].HeaderText = "Injury Date";
                dgv.Columns["InjuryType"].HeaderText = "Injury Type";
                dgv.Columns["DaysOut"].HeaderText = "Days Out";
                dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading Player Injuries: " + ex.Message, "DB Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}