using System;
using System.Windows.Forms;
using EPL_DBMS.DataAccess;

namespace EPL_DBMS.Forms
{
    public partial class PlayerStatsForm : Form
    {
        private readonly int? _playerId;

        public PlayerStatsForm()
        {
            InitializeComponent();
            _playerId = null;
            this.Text = "League Top Performers";
            this.Load += Form_Load;
        }

        public PlayerStatsForm(int playerId, string playerName)
        {
            InitializeComponent();
            _playerId = playerId;
            this.Text = $"{playerName} - Match Statistics";
            this.Load += Form_Load;
        }

        private void Form_Load(object sender, EventArgs e)
        {
            try
            {
                var dgv = dataGridViewPlayerStats;

                // --- PURE ADO.NET ROUTING ---
                if (_playerId.HasValue)
                {
                    // Execute specific SQL Query
                    dgv.DataSource = PlayerStatRepository.GetById(_playerId.Value);
                    dgv.Columns["PlayerId"].Visible = false;
                }
                else
                {
                    // Execute global SQL Query
                    dgv.DataSource = PlayerStatRepository.GetAllPlayerStats();
                    dgv.Columns["PlayerId"].HeaderText = "Player ID";
                }

                dgv.Columns["PlayerStatId"].Visible = false;
                dgv.Columns["MatchId"].HeaderText = "Match ID";
                dgv.Columns["GoalsScored"].HeaderText = "Goals";
                dgv.Columns["Assists"].HeaderText = "Assists";
                dgv.Columns["YellowCards"].HeaderText = "Yellow Cards";
                dgv.Columns["RedCards"].HeaderText = "Red Cards";
                dgv.Columns["MinutesPlayed"].HeaderText = "Minutes Played";
                dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading Player Stats: " + ex.Message, "DB Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}